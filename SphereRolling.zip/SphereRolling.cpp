#include <stdio.h>
#include <math.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Angel-yjc.h"
using namespace std;


typedef Angel::vec3  color3; // color3 definition
typedef Angel::vec3  point3; // point3 definition

typedef Angel::vec4 color4; // color4 definition
typedef Angel::vec4 point4; // point4 definition

const vec4 VRP = { 7.0, 3.0, -10.0, 1.0 }; // VRP Variable - our Eye
const vec4 VPN = { -7.0, -3.0, 10.0, 0.0 }; // VPN Variable - Where we are looking at
const vec4 VUP = { 0.0, 1.0, 0.0, 0.0 }; // VUP Variable - Y direction
const vec4 locA = { -4, 1, 4, 1 }; // A location
const vec4 locB = { -1, 1, -4, 1 }; // B location
const vec4 locC = { 3, 1, 5, 1 }; // C location

const vec4 lightSource = { -14, 12, -3, 1 }; // Light Source Point
const color4 ambientLight(1.0, 1.0, 1.0, 1.0); // Ambient light color
const color4 shadowColor(.25, .25, .25, 0.65); // Shadow color
const color4 directionalAmbient(0.0, 0.0, 0.0, 1.0); // Directional light
const color4 directionalDiffuse(0.8, 0.8, 0.8, 1.0); // Diffusion color
const color4 directionalSpecular(0.2, 0.2, 0.2, 1.0); // Specular color
const vec4 directionVec = (0.1, 0.0, -1.0, 0.0); // Direction of light

const vec4 positionalDiffuse = { 1.0, 1.0, 1.0, 1.0 }; // Positional diffuse light
const vec4 positionalSpecular = { 1.0, 1.0, 1.0, 1.0 }; // Positional specular light
const vec4 positionalAmbient = { 0.0, 0.0, 0.0, 1.0 }; // Positional ambient light

const vec4 SLPos = { -6.0, 0.0, -4.5, 1.0 }; // Spotlight position
const float SLExp = 15.0; // Spotlight exponent
const float cutoff = 20.0; // Spotlight cutoff angle

float const_att = 2.0f; // Constant attenuation
float linear_att = 0.01f; // Linear attenuation
float quad_att = 0.001f; // quadratic attenuation

// Floor material values
color4 floorAmbient(0.2f, 0.2f, 0.2f, 1.0f);
color4 floorDiffuse(0.0f, 1.0f, 0.0f, 1.0f);
color4 floorSpecular(0.0f, 0.0f, 0.0f, 1.0f);

// Sphere material values
color4 sphereAmbient(0.2, 0.2, 0.2, 1.0);
color4 sphereDiffuse(1.0, 0.84, 0.0, 1.0);
color4 sphereSpecular(1.0, 0.84, 0.0, 1.0);

// Floor material products
color4 floorGA = floorAmbient * ambientLight;
color4 floorAP = directionalAmbient * floorAmbient;
color4 floorDP = directionalDiffuse * floorDiffuse;
color4 floorSP = directionalSpecular * floorSpecular;

float  shininessCoefficient = 125.0f; // Shininess coefficient

// Sphere material products
color4 sphereGA = sphereAmbient * ambientLight;
color4 sphereAP = directionalAmbient * sphereAmbient;
color4 sphereDP = directionalDiffuse * sphereDiffuse;
color4 sphereSP = directionalSpecular * sphereSpecular;

vec3 resultant; // Resultant vector from segment end - segment start
const vec3 oY(0, 1, 0); // oY position for rotation

vec4 currSeg; // current segment
vec4 nextSeg; // next segment
vec4 lineSeg; // Line we are going on

GLuint Angel::InitShader(const char* vShaderFile, const char* fShaderFile); // Init shader function

GLuint programColor;       /* vColor shader object id */
GLuint programNormal; /* vNormal Shader object id*/
GLuint programTexture; // texture program object id
GLuint programParticles; // particle program object id
GLuint sphere_buffer;   /* vertex buffer object id for sphere */
GLuint sphereNormal; // vertex buffer object idfor sphere normlas
GLuint floor_buffer;  /* vertex buffer object id for floor */
GLuint floorNormal; // floorNormals buffer object id
GLuint floor_text; // floor texture buffer object id
GLuint x_buffer; // Vertex buffer object id for xAxis line
GLuint y_buffer; // Vertex buffer object id for yAxis line
GLuint z_buffer; // Vertex buffer object id for zAxis line
GLuint shadow_buffer; // Vertex buffer object id for the shadow
GLuint particles; // particle buffer object id

GLuint  model_view;  // model-view matrix uniform shader variable location
GLuint  projection;  // projection matrix uniform shader variable location
GLuint fogVar; // Fog variable identifier
GLuint isSphereT; // isSphere identifier
GLuint TMST; // Texture map sphere identifier
GLuint UTSwapT; // U or T identifier
GLuint latticeFlagT; // Lattice flag identifier
GLuint isColorT; // Is it a color object identifier
GLuint TMSDirectT; // texture map sphere identifier
GLuint timeVar; // Time variable identifier
GLuint MV; // Model view matrix identifier
GLuint textureViewT; // Texture view identifier
GLuint PJ; // Projection matrix identifier
GLuint programSphereTM; // sphere texture map program id
GLuint TMSPHERE; // Texture map sphere buffer object id
GLuint isColorandSphereT;

// Projection transformation parameters
GLfloat  fovy = 45.0;  // Field-of-view in Y direction angle (in degrees)
GLfloat  aspect;       // Viewport aspect ratio
GLfloat  zNear = 0.5, zFar = 15; // z near and z far values for perspective function

GLfloat angle = 0.0; // rotation angle in degrees
vec4 init_eye = VRP; // initial viewer position
vec4 eye = init_eye; // current viewer position

/*	Create checkerboard texture	*/
#define	ImageWidth 32 // image width
#define	ImageHeight 32 // image height
static  GLubyte Image[ImageHeight][ImageWidth][4]; // array to store values of our texture image
#define	stripeImageWidth 32
GLubyte stripeImage[4 * stripeImageWidth]; // array to store values of our strip

static GLuint texName; // identifier for our 2d texture
static GLuint texStripName; // identifier for our strip

int animationFlag = 0; // Chooses if the ball should move
bool rightMouse = false;

const int floor_NumVertices = 6; //(1 face)*(2 triangles/face)*(3 vertices/triangle)
point4 floor_points[floor_NumVertices]; // positions for all vertices
color3 floor_colors[floor_NumVertices]; // colors for all vertices

int sphereNumVertices; // Number of vertices in our sphere
vector<point4> vertices; // Vector holding point3s of our vertices
vector<color3> colors; // Vector holding color3s of our vertices


point4 sphere_points[4000]; // Holds our sphere points
point3 sphereNormals[4000]; // Holds our sphere normals
color3 sphere_colors[4000]; // Holds our sphere colors

point3 shadow_points[4000]; // Holds our shadow points
color3 shadow_colors[4000]; // Holds our shadow colors

vec3 particleVelocities[300]; // Holds the velocity of our particles
color3 particleColors[300]; // Holds the colors of our particles

vec3 floorNormals[6]; // Holds the normals for our floor

point4 floorVertices[4] = {
    point4(5, 0, 8, 1),
    point4(5, 0, -4, 1),
    point4(-5, 0, -4, 1),
    point4(-5, 0, 8, 1)
}; // Stores the points of our floor plane

vec2 floorTexCoord[6] = {
  vec2(0, 0),
  vec2(0, 6),
  vec2(5, 6),
  vec2(5, 6),
  vec2(5, 0),
  vec2(0, 0),
}; // Texture coordinates for the floor

point3 xAxisVertices[3] = {
    point3(0, 0.02, 0),
    point3(5, 0.02, 0),
    point3(10, 0.02, 0)
}; // Stores the values for the line of our xAxis

point3 yAxisVertices[3] = {
    point3(0, 0, 0),
    point3(0, 5, 0),
    point3(0, 10, 0)
}; // Stores the values for the line of our yAxis

point3 zAxisVertices[3] = {
    point3(0, 0.02, 0),
    point3(0, 0.02, 5),
    point3(0, 0.02, 10)
}; // Stores the values for the line of our zAxis

color3 xAxisColors[3] = {
    color3(1, 0, 0),
    color3(1, 0, 0),
    color3(1, 0, 0)
}; // Stores the colors for the line of our xAxis

color3 yAxisColors[3] = {
    color3(1, 0, 1),
    color3(1, 0, 1),
    color3(1, 0, 1)
}; // Stores the colors for the line of our yAxis

color3 zAxisColors[3] = {
    color3(0, 0, 1),
    color3(0, 0, 1),
    color3(0, 0, 1)
}; // Stores the colors for the line of our zAxis
// RGBA colors
color3 vertex_colors[8] = {
    color3(0.0, 0.0, 0.0),  // 0 - black
    color3(1.0, 0.0, 0.0),  // 1 - red
    color3(1.0, 1.0, 0.0),  // 2 - yellow
    color3(0.0, 1.0, 0.0),  // 3 - green
    color3(0.0, 0.0, 1.0),  // 4 - blue
    color3(1.0, 0.0, 1.0),  // 5 - magenta
    color3(1.0, 1.0, 1.0),  // 6 - white
    color3(0.0, 1.0, 1.0)   // 7 - cyan
};

mat4 M = { // Accumulation matrix
    1, 0, 0, 0,
    0, 1, 0, 0,
    0, 0, 1, 0,
    0, 0, 0, 1
};

mat4 shadowProject; // Holds the matrix transformation to calculate shadow projection

float animationStartTime; // Fireworks starting time for the animation
float timeElapsed; // time since start of animation in fireworks


// Flags
bool wireframeSphereFlag = true; // Toggles wireframe
bool shadowFlag = false; // Toggles shadow
bool lightingFlag = false; // Toggles lighting
bool smoothShadingFlag = false; // Chooses smooth shading
bool flatShadingFlag = true; // Chooses flat shading
bool pointSource = true; // Chooses point source lighting
bool spotLight = false; // Chooses spot light lighting
bool blendingFlag = false; // Chooses if we are blending
bool TMGFlag = false; // Texture Map the ground flag
bool fireworkFlag = false; // Fireworks flag

// Sphere texture flags
int isSphere = 0; // Is it the sphere
int TMS = 0; // Is it texture mapped and how is it texture mapped
int TMSDirect = 0; // Slanted or not
int textureView = 0; // Eye or Object view
int latticeFlag = 0; // Is the lattice effect on
int UTSwap = 0; // U or T for lattice

int fogType = 0; // Controls the fog levels


// Functions for reading file
int ReadFromFile(const string& filename); // Reads from file if that is chosen
string GetFileName(void); // Gets the filename as an input from the user

// OpenGL Event Functions
void reshape(int width, int height); // Reshape function for when window size changes (controls aspect ratio)
void idle(void); // Idle function (changes the angle for the display)
void display(void); // Display function
void init(); // Initializes Vertex Buffers
void keyboard(unsigned char key, int x, int y); // Keyboard input from the user
void mouse(int button, int state, int x, int y); // Listens for mouse input

// Options menus
void shadow(int id); // Shadow submenu
void lighting(int id); // Lighting submenu
void shading(int id);
void options(int id); // Options menu for left click
void lightingType(int id); // Options menu for spotlight or point source
void fog(int id); // Options to handle the fog
void TexMG(int id);
void blending(int id); // Handles blending
void fireworks(int id);
void TexMS(int id);


// Helper Functions for creating shapes
void drawObjColor(GLuint buffer, int num_vertices); // Draws our objects
void drawObjNormal(GLuint buffer, int num_vertices); // Draws objects using our normal program
void drawObjTexture(GLuint buffer, int num_vertices); // Draws the texture for the floor
void drawObjParticles(GLuint buffer, int num_particles, mat4 mv, mat4 p); // Draws the particles
void floor(); // calculates the floor
void calcNewSegment(const vec4& one, const vec4& two); // Calculates the next rolling segment
void calculateShadowPoints(); // Calculates the shadow points
void calculateSphereNormals(); // Calculates the sphere normals
void drawAxis(); // Draw the axis
void drawSphere(mat4 p, mat4 mv); // Draw the sphere
void drawShadow(); // Draw the shadow
void drawFloor(); // Draw the floor
void SetUpFloorLighting(mat4 mv); // Set up the floor lighting
void SetUpSphereLighting(mat4 mv); // Set up the sphere lighting
void SetUpColorProgram(mat4 p, mat4 mv); // Sets up our color program
void SetUpNormalProgram(mat4 p, mat4 mv, mat3 normal); // Sets up our normal program
void SetUpTextureProgram(mat4 p, mat4 mv); // Sets up our texture program
void drawFSNoBlend(mat4 p, mat4 mv, mat3 normal); // Draws the floor and shadow without blending
void drawFSBlend(mat4 p, mat4 mv, mat3 normal); // Draws the floor and shadow with blending
void image_set_up(void); // Sets up our 2d texture image and our 1d texture strip
void generateParticleValues(void); // Generates the particle values for our fireworks.

int main(int argc, char** argv) {
    glutInit(&argc, argv); // Initializes with arguments
    glutInitDisplayMode(GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH); // Double buffer color RGA display
    glutInitWindowSize(600, 600); // 600 x 600 window
    glutCreateWindow("Sphere Rolling"); // Calls the assignment assignment 4

    int err = glewInit();
    if (GLEW_OK != err)
    {
        printf("Error: glewInit failed: %s\n", (char*)glewGetErrorString(err));
        exit(1);
    }

    // Get info of GPU and supported OpenGL version
    printf("Renderer: %s\n", glGetString(GL_RENDERER));
    printf("OpenGL version supported %s\n", glGetString(GL_VERSION));

    glutDisplayFunc(display); // Set display function to display
    glutReshapeFunc(reshape); // Set reshape function to reshape
    glutIdleFunc(NULL); // Set idle function to idle - Set to NULL by default to make it so the ball starts disabled
    glutKeyboardFunc(keyboard); // Set keyboard function to keyboard
    glutMouseFunc(mouse);

    string filename = GetFileName(); // Gets the file name
    sphereNumVertices = ReadFromFile(filename); // Uses the file name to get the vertex points and the amount of vertices

    init(); // Calls init to initialize our buffers
    glutMainLoop(); // Enter the main loop
}
// Gets the input from the user

string GetFileName(void) {
    string name;
    cout << "What is the name of the file" << endl;
    cin >> name;
    return name;
}
// Reads in the file given the file name and will then store the values of the vertices

int ReadFromFile(const string& filename) {
    ifstream file;
    file.open(filename);

    int triCount;

    if (!file) {
        cerr << "Could not open file" << endl;
        exit(1);
    }

    file >> triCount;

    float n, xVal, yVal, zVal; // Stores the values from the input

    point3 point; // Stores our points
    color3 color; // Stores our colors

    for (int i = 0; i < triCount; i++) {
        file >> n;
        for (int j = 0; j < n; j++) {
            file >> xVal;
            file >> yVal;
            file >> zVal;
            point.x = xVal, point.y = yVal, point.z = zVal;
            vertices.push_back(point);
        }
    }

    color.x = 1.0, color.y = 0.84, color.z = 0;

    for (int i = 0; i < triCount * 3; i++) {
        sphere_colors[i].x = color.x, sphere_colors[i].y = color.y, sphere_colors[i].z = color.z;
        shadow_colors[i].x = .25, shadow_colors[i].y = .25, shadow_colors[i].z = .25;
        sphere_points[i].x = vertices[i].x, sphere_points[i].y = vertices[i].y, sphere_points[i].z = vertices[i].z, sphere_points[i].w = 1;
        shadow_points[i].y = 0;
    }

    file.close();

    return (triCount * 3); // Returns the amount of vertices
}
// Reshape function, sets the aspect value as well

void reshape(int width, int height)
{
    glViewport(0, 0, width, height);
    aspect = (GLfloat)width / (GLfloat)height;
    glutPostRedisplay();
}
// increases the angle while running

void idle(void) {
    vec4 check = (angle * M_PI / 180) * (resultant /
        sqrt(resultant.x * resultant.x + resultant.y + resultant.y +
            resultant.z * resultant.z));

    if (sqrt(check.x * check.x + check.y * check.y + check.z * check.z) >
        sqrt(resultant.x * resultant.x + resultant.y * resultant.y + resultant.z * resultant.z)) { // Check if the segment has ended

        M = M * Rotate(angle, lineSeg.x, lineSeg.y, lineSeg.z); // Accumulation vector

        if (currSeg.x == locA.x && currSeg.y == locA.y && currSeg.z == locA.z)
            calcNewSegment(locB, locC); // Moves from segment A to segment B
        else if (currSeg.x == locB.x && currSeg.y == locB.y && currSeg.z == locB.z)
            calcNewSegment(locC, locA); // Moves from segment B to segment C
        else
            calcNewSegment(locA, locB); // Moves from segment C to segment A

        angle = 0; // Reset angle
    }
    angle += 0.03f; // Controls angle for display function

    glutPostRedisplay(); // Calls display
}

void display(void) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    mat4  p = Perspective(fovy, aspect, zNear, zFar);
    vec4  at = VRP + VPN; // Calculates At
    vec4  up = VUP; // Calculates up
    mat4  mv = LookAt(eye, at, up); // Model view matrix
    mat3 normal_matrix = NormalMatrix(mv, 1);
   
    isSphere = 0;

    if (fireworkFlag) // Draws the particles if they are enabled
        drawObjParticles(particles, 300, mv, p);
    
    SetUpColorProgram(p, mv);
    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

    drawAxis();
    
    // Draws the shadow and floor either blended or not blended
    if (shadowFlag && blendingFlag)
        drawFSBlend(p, mv, normal_matrix);
    else
        drawFSNoBlend(p, mv, normal_matrix);
    
    mv = LookAt(eye, at, up) // LookAt for sphere
        * Translate(currSeg + (angle * M_PI / 180) * (resultant / // Multiplies by Translation
            sqrt(resultant.x * resultant.x + resultant.y + resultant.y +
                resultant.z * resultant.z)))
        * Rotate(angle, lineSeg.x, lineSeg.y, lineSeg.z) // Multiplies by Rotation matrix
        * M; // Multiplies by accumulation of rotation matrix

    mat4 sphereMV = LookAt(eye, at, up)
        * Translate(currSeg + (angle * M_PI / 180) * (resultant / // Multiplies by Translation
            sqrt(resultant.x * resultant.x + resultant.y + resultant.y +
                resultant.z * resultant.z)));

    // Sets up the correct program to draw the current iteration of the sphere
    if (lightingFlag || TMS != 0) {
        SetUpSphereLighting(sphereMV);
        glUniformMatrix4fv(model_view, 1, GL_TRUE, mv);
        normal_matrix = NormalMatrix(mv, 1);
        glUniformMatrix3fv(glGetUniformLocation(programNormal, "Normal_Matrix"),
            1, GL_TRUE, normal_matrix);
    } else if (TMS == 0) {
        SetUpColorProgram(p, mv);
    }
    
    drawSphere(p, mv);
    
    glutSwapBuffers(); // Updates the screen
    
}

// Draws texture floor
void drawObjTexture(GLuint buffer, int num_vertices) {
    //--- Activate the vertex buffer object to be drawn ---//
    glBindBuffer(GL_ARRAY_BUFFER, buffer);

    /*----- Set up vertex attribute arrays for each vertex attribute -----*/
    GLuint vPosition = glGetAttribLocation(programTexture, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0,
        BUFFER_OFFSET(0));

    GLuint vTexCoord = glGetAttribLocation(programTexture, "vTexCoord");
    glEnableVertexAttribArray(vTexCoord);
    glVertexAttribPointer(vTexCoord, 2, GL_FLOAT, GL_FALSE, 0,
        BUFFER_OFFSET(sizeof(floor_points)));
    // the offset is the (total) size of the previous vertex attribute array(s)

    /* Draw a sequence of geometric objs (triangles) from the vertex buffer
       (using the attributes specified in each enabled vertex attribute array) */
    glDrawArrays(GL_TRIANGLES, 0, num_vertices);

    /*--- Disable each vertex attribute array being enabled ---*/
    glDisableVertexAttribArray(vPosition);
    glDisableVertexAttribArray(vTexCoord);
}

// Draws objects using color program
void drawObjColor(GLuint buffer, int num_vertices)
{

    //--- Activate the vertex buffer object to be drawn ---//
    glBindBuffer(GL_ARRAY_BUFFER, buffer);

    /*----- Set up vertex attribute arrays for each vertex attribute -----*/
    GLuint vPosition = glGetAttribLocation(programColor, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint vColor = glGetAttribLocation(programColor, "vColor");
    glEnableVertexAttribArray(vColor);
    glVertexAttribPointer(vColor, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(point3) * num_vertices));
    // the offset is the (total) size of the previous vertex attribute array(s)

    /* Draw a sequence of geometric objs (triangles) from the vertex buffer
    (using the attributes specified in each enabled vertex attribute array) */
    glDrawArrays(GL_TRIANGLES, 0, num_vertices);

    /*--- Disable each vertex attribute array being enabled ---*/
    glDisableVertexAttribArray(vPosition);
    glDisableVertexAttribArray(vColor);
}

// Draws particles
void drawObjParticles(GLuint buffer, int num_particles, mat4 mv, mat4 p) {
    glUseProgram(programParticles); // Use the shader program for color

    model_view = glGetUniformLocation(programParticles, "model_view");
    projection = glGetUniformLocation(programParticles, "projection");

    glUniformMatrix4fv(projection, 1, GL_TRUE, p); // GL_TRUE: matrix is row-major
    glUniformMatrix4fv(model_view, 1, GL_TRUE, mv); // GL_TRUE: matrix is row-major
    
    timeElapsed = glutGet(GLUT_ELAPSED_TIME);
    
    if (timeElapsed > animationStartTime + 5000)
        animationStartTime = timeElapsed;
    
    float timeValue = (timeElapsed - animationStartTime) * 0.001;

    timeVar = glGetUniformLocation(programParticles, "timeVal");
    glUniform1f(timeVar, timeValue);
    
    glBindBuffer(GL_ARRAY_BUFFER, particles);

    GLuint vVelocity = glGetAttribLocation(programParticles, "vVelocity");
    glEnableVertexAttribArray(vVelocity);
    glVertexAttribPointer(vVelocity, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

    GLuint vColor = glGetAttribLocation(programParticles, "vColor");
    glEnableVertexAttribArray(vColor);
    glVertexAttribPointer(vColor, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(sizeof(vec3) * num_particles));

    glPointSize(3.0);
    glDrawArrays(GL_POINTS, 0, num_particles);

    glDisableVertexAttribArray(vVelocity);
    glDisableVertexAttribArray(vColor);
}

// Draws object using normal program
void drawObjNormal(GLuint buffer, int num_vertices) {
    //--- Activate the vertex buffer object to be drawn ---//
    glBindBuffer(GL_ARRAY_BUFFER, buffer);

    /*----- Set up vertex attribute arrays for each vertex attribute -----*/
    GLuint vPosition = glGetAttribLocation(programNormal, "vPosition");
    glEnableVertexAttribArray(vPosition);
    glVertexAttribPointer(vPosition, 4, GL_FLOAT, GL_FALSE, 0,
        BUFFER_OFFSET(0));

    GLuint vNormal = glGetAttribLocation(programNormal, "vNormal");
    glEnableVertexAttribArray(vNormal);
    glVertexAttribPointer(vNormal, 3, GL_FLOAT, GL_FALSE, 0,
        BUFFER_OFFSET(sizeof(point4) * num_vertices));

    // the offset is the (total) size of the previous vertex attribute array(s)

    /* Draw a sequence of geometric objs (triangles) from the vertex buffer
       (using the attributes specified in each enabled vertex attribute array) */
    glDrawArrays(GL_TRIANGLES, 0, num_vertices);

    /*--- Disable each vertex attribute array being enabled ---*/
    glDisableVertexAttribArray(vPosition);
    glDisableVertexAttribArray(vNormal);}

// Initializes all of our buffers, particles, and textures
void init() {
    generateParticleValues();
    int shadowOptionsID = glutCreateMenu(shadow); // Initializes shadow submenu
    glutSetMenuFont(shadowOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in shadows
    glutAddMenuEntry(" Yes ", 1);
    glutAddMenuEntry(" No ", 2);

    int lightingOptionsID = glutCreateMenu(lighting); // Initializes lighting submenu
    glutSetMenuFont(lightingOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in lighting
    glutAddMenuEntry(" Yes ", 1);
    glutAddMenuEntry(" No ", 2);

    int blendingShadowOptionsID = glutCreateMenu(blending); // Initializes lighting submenu
    glutSetMenuFont(blendingShadowOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in lighting
    glutAddMenuEntry(" Yes ", 1);
    glutAddMenuEntry(" No ", 2);

    int TMGOptionsID = glutCreateMenu(TexMG);
    glutSetMenuFont(TMGOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in lighting
    glutAddMenuEntry(" No ", 1);
    glutAddMenuEntry(" Yes ", 2);
    
    int FireworkOptionsID = glutCreateMenu(fireworks);
    glutSetMenuFont(FireworkOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in lighting
    glutAddMenuEntry(" No ", 1);
    glutAddMenuEntry(" Yes ", 2);

    int shadingOptionsID = glutCreateMenu(shading);
    glutSetMenuFont(lightingOptionsID, GLUT_BITMAP_HELVETICA_18);
    glutAddMenuEntry(" Flat Shading ", 1);
    glutAddMenuEntry(" Smooth Shading ", 2);

    int lightingTypeOptionsID = glutCreateMenu(lightingType);
    glutSetMenuFont(lightingOptionsID, GLUT_BITMAP_HELVETICA_18);
    glutAddMenuEntry(" Spot Light ", 1);
    glutAddMenuEntry(" Point Source ", 2);
    
    int fogTypeOptionsID = glutCreateMenu(fog);
    glutSetMenuFont(fogTypeOptionsID, GLUT_BITMAP_HELVETICA_18);
    glutAddMenuEntry(" No Fog ", 1);
    glutAddMenuEntry(" Linear ", 2);
    glutAddMenuEntry(" Exponential ", 3);
    glutAddMenuEntry(" Exponential Square ", 4);

    int TMSOptionsID = glutCreateMenu(TexMS);
    glutSetMenuFont(TMSOptionsID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in lighting
    glutAddMenuEntry(" No ", 1);
    glutAddMenuEntry(" Yes - Contour Lines ", 2);
    glutAddMenuEntry(" Yes - Checkerboard ", 3);

    int optionsMenuID = glutCreateMenu(options); // Initializes our options menu
    glutSetMenuFont(optionsMenuID, GLUT_BITMAP_HELVETICA_18); // Sets our font to helvetica size 18 in options
    glutAddMenuEntry(" Default View Point ", 2); // Adds default view point button
    glutAddMenuEntry(" Wireframe Sphere ", 3); // Toggles wireframe sphere on and off
    glutAddSubMenu(" Shadow ", shadowOptionsID); // Uses the shadow sub-menu
    glutAddSubMenu(" Enable Lighting ", lightingOptionsID); // Enables or disables lighting
    glutAddSubMenu(" Shading ", shadingOptionsID);
    glutAddSubMenu(" Light Source ", lightingTypeOptionsID);
    glutAddSubMenu(" Fog Options ", fogTypeOptionsID);
    glutAddSubMenu(" Blending Shadow ", blendingShadowOptionsID);
    glutAddSubMenu(" Texture Mapped Ground ", TMGOptionsID);
    glutAddSubMenu(" Fireworks ", FireworkOptionsID);
    glutAddSubMenu(" Texture Mapped Sphere ", TMSOptionsID);
    glutAddMenuEntry(" Quit ", 1); // Adds quit button

    glutAttachMenu(GLUT_LEFT_BUTTON);


    calcNewSegment(locA, locB);

    image_set_up();
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    /*--- Create and Initialize a texture object ---*/
    glGenTextures(1, &texName);      // Generate texture obj name(s)

    glActiveTexture(GL_TEXTURE1);  // Set the active texture unit to be 0 
    glBindTexture(GL_TEXTURE_2D, texName); // Bind the texture to this texture unit

    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ImageWidth, ImageHeight,
        0, GL_RGBA, GL_UNSIGNED_BYTE, Image);

    /*--- Create and Initialize a texture object ---*/
    glGenTextures(1, &texStripName);      // Generate texture obj name(s)

    glActiveTexture(GL_TEXTURE1);  // Set the active texture unit to be 0 
    glBindTexture(GL_TEXTURE_1D, texStripName); // Bind the texture to this texture unit

    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

    glTexImage1D(GL_TEXTURE_1D, 0, GL_RGBA, ImageWidth, 
        0, GL_RGBA, GL_UNSIGNED_BYTE, stripeImage);


    // Create and initialize a vertex buffer object for sphere, to be used in display()
    glGenBuffers(1, &shadow_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, shadow_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(point3) * sphereNumVertices + sizeof(color3) * sphereNumVertices, NULL, GL_STATIC_DRAW);
    calculateShadowPoints();
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(point3) * sphereNumVertices, sizeof(color3) * sphereNumVertices, shadow_colors);

    glGenBuffers(1, &sphere_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, sphere_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(point4) * sphereNumVertices + sizeof(color3) * sphereNumVertices, NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(point4) * sphereNumVertices, sphere_points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(point4) * sphereNumVertices, sizeof(color3) * sphereNumVertices, sphere_colors);

    glGenBuffers(1, &sphereNormal);
    glBindBuffer(GL_ARRAY_BUFFER, sphereNormal);
    glBufferData(GL_ARRAY_BUFFER, sizeof(point4) * sphereNumVertices + sizeof(color3) * sphereNumVertices, NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(point4) * sphereNumVertices, sphere_points);
    calculateSphereNormals();

    floor();
    glGenBuffers(1, &floorNormal);
    glBindBuffer(GL_ARRAY_BUFFER, floorNormal);
    glBufferData(GL_ARRAY_BUFFER, sizeof(floor_points) + sizeof(floorNormals), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(floor_points), floor_points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(floor_points), sizeof(floorNormals), floorNormals);

    glGenBuffers(1, &floor_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, floor_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(floor_points) + sizeof(floor_colors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(floor_points), floor_points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(floor_points), sizeof(floor_colors), floor_colors);

    glGenBuffers(1, &floor_text);
    glBindBuffer(GL_ARRAY_BUFFER, floor_text);
    glBufferData(GL_ARRAY_BUFFER, sizeof(floor_points) + sizeof(floorTexCoord), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(floor_points), floor_points);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(floor_points), sizeof(floorTexCoord), floorTexCoord);

    // Create and initialize a vertex buffer object for x-axis, to be used in display()
    glGenBuffers(1, &x_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, x_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(xAxisVertices) + sizeof(xAxisColors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(xAxisVertices), xAxisVertices);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(xAxisVertices), sizeof(xAxisColors), xAxisColors);

    // Create and initialize a vertex buffer object for y-axis, to be used in display()
    glGenBuffers(1, &y_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, y_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(yAxisVertices) + sizeof(yAxisColors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(yAxisVertices), yAxisVertices);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(yAxisVertices), sizeof(yAxisColors), yAxisColors);

    // Create and initialize a vertex buffer object for z-axis, to be used in display()
    glGenBuffers(1, &z_buffer);
    glBindBuffer(GL_ARRAY_BUFFER, z_buffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(zAxisVertices) + sizeof(zAxisColors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(zAxisVertices), zAxisVertices);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(zAxisVertices), sizeof(zAxisColors), zAxisColors);

    glGenBuffers(1, &particles);
    glBindBuffer(GL_ARRAY_BUFFER, particles);
    glBufferData(GL_ARRAY_BUFFER, sizeof(particleVelocities) + sizeof(particleColors), NULL, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(particleVelocities), particleVelocities);
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(particleVelocities), sizeof(particleColors), particleColors);

    glGenBuffers(1, &TMSPHERE);
    glBindBuffer(GL_ARRAY_BUFFER, TMSPHERE);
    glBufferData(GL_ARRAY_BUFFER, sizeof(sphere_points), nullptr, GL_STATIC_DRAW);
    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(sphere_points), sphere_points);

    programColor = InitShader("vshader42.glsl", "fshader53.glsl"); // Initializes shaders
    programNormal = InitShader("vshader53.glsl", "fshader53.glsl");
    programTexture = InitShader("vTexture.glsl", "fshader53.glsl");
    programParticles = InitShader("vParticles.glsl", "fParticles.glsl");

    glEnable(GL_DEPTH_TEST);
    glClearColor(0.529, 0.807, 0.92, 0.0); // Sets the sky to light blue
    glLineWidth(2.0);
}

// Keyboard function
void keyboard(unsigned char key, int x, int y) {
    switch (key) {
        // Changes the eye values in the x y or z position
    case 'X': eye[0] += 1.0; break;
    case 'x': eye[0] -= 1.0; break;
    case 'Y': eye[1] += 1.0; break;
    case 'y': eye[1] -= 1.0; break;
    case 'Z': eye[2] += 1.0; break;
    case 'z': eye[2] -= 1.0; break;

    case 'b': case 'B': // Toggle between animation and non-animation
        if (!rightMouse) {
            rightMouse = true; // Enables the right mouse and disables using b to
                                // stop and start rolling
            animationFlag = 1 - animationFlag; // Turns on animations
            glutIdleFunc(idle); // Enables idle
        }
        break;
    case 'v': case 'V':
        TMSDirect = 0; // Changes to verticle
        break;
    case 's': case 'S':
        TMSDirect = 1; // Changes to slanted
        break;
    case 'e': case 'E':
        textureView = 0; // Changes to eye frame for textures
        break;
    case 'o': case 'O':
        textureView = 1; // Changes to object frame for textures
        break;
    case 'u': case 'U':
        UTSwap = 0; // Upright
        break;
    case 't': case 'T':
        UTSwap = 1; // Tilted
        break;
    case 'l': case 'L':
        latticeFlag = 1 - latticeFlag; // Toggles the lattice flag
        break;
    }

    glutPostRedisplay(); // Will then redisplay the screen
}

// Sets our floors values to the array
void floor() { // Sets up the floor vertices to be added
    vec4 u = vertices[1] - vertices[0];
    vec4 v = vertices[2] - vertices[0];

    vec3 normal = normalize(cross(u, v));

    floorNormals[0] = normal; floor_colors[0] = vertex_colors[3]; floor_points[0] = floorVertices[0];
    floorNormals[1] = normal; floor_colors[1] = vertex_colors[3]; floor_points[1] = floorVertices[1];
    floorNormals[2] = normal; floor_colors[2] = vertex_colors[3]; floor_points[2] = floorVertices[2];

    floorNormals[3] = normal; floor_colors[3] = vertex_colors[3]; floor_points[3] = floorVertices[2];
    floorNormals[4] = normal; floor_colors[4] = vertex_colors[3]; floor_points[4] = floorVertices[3];
    floorNormals[5] = normal; floor_colors[5] = vertex_colors[3]; floor_points[5] = floorVertices[0];
}

// Calculates rolling transition segment
void calcNewSegment(const vec4& one, const vec4& two) { // Creates the segments for the different vectors
    currSeg.x = one.x, currSeg.y = one.y, currSeg.z = one.z; // Takes start x y and z
    nextSeg.x = two.x, nextSeg.y = two.y, nextSeg.z = two.z; // Takes end x y and z
    resultant.x = nextSeg.x - currSeg.x, // Takes the difference for cross product
        resultant.y = nextSeg.y - currSeg.y,
        resultant.z = nextSeg.z - currSeg.z;
    lineSeg = cross(oY, resultant); // Takes cross product for rotation
}

// Calculates the new shadow points
void calculateShadowPoints() {
    vec4 values;

    shadowProject = (Translate(currSeg + (angle * M_PI / 180) * (resultant / // Multiplies by Translation
        sqrt(resultant.x * resultant.x + resultant.y + resultant.y +
            resultant.z * resultant.z)))
        * Rotate(angle, lineSeg.x, lineSeg.y, lineSeg.z) // Multiplies by Rotation matrix
        * M);

    for (int i = 0; i < sphereNumVertices; i++) {
        values = shadowProject * sphere_points[i];
        shadow_points[i].x = ((shadow_points[i].y - lightSource.y) / (values.y - lightSource.y))
            * (values.x - lightSource.x) + lightSource.x;
        shadow_points[i].z = ((shadow_points[i].y - lightSource.y) / (values.y - lightSource.y))
            * (values.z - lightSource.z) + lightSource.z;
    }

    glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(point3) * sphereNumVertices, shadow_points);
}

// Allows right click to stop and start the program
void mouse(int button, int state, int x, int y) {
    // If right click is clicked, will start or stop the ball
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN && rightMouse) {
        animationFlag = 1 - animationFlag;
        if (animationFlag == 1)
            glutIdleFunc(idle);
        else
            glutIdleFunc(NULL);
    }
}

// Options menu - Bound to left click
void options(int id) {
    switch (id) {
    case 1:
        exit(EXIT_SUCCESS); // Closes program
        break;
    case 2:
        eye = init_eye; // Resets eye
        break;
    case 3:
        wireframeSphereFlag = !wireframeSphereFlag;
        if (wireframeSphereFlag)
            lightingFlag = false;
        break;
    }
    glutPostRedisplay(); // Displays changes
}

// Texture map ground options
void TexMG(int id) {
    switch (id) {
    case 1:
        TMGFlag = false;
        break;
    case 2:
        TMGFlag = true;
        break;
    }
    glutPostRedisplay();
}

// Shadow options
void shadow(int id) {
    switch (id) {
    case 1:
        shadowFlag = true;
        break;
    case 2:
        shadowFlag = false;
        break;
    }
    glutPostRedisplay(); // Displays changes
}

// Blending options
void blending(int id) {
    switch (id) {
    case 1:
        blendingFlag = true;
        break;
    case 2:
        blendingFlag = false;
        break;
    }
    glutPostRedisplay(); // Displays changes
}

// Lighting options
void lighting(int id) {
    switch (id) {
    case 1:
        lightingFlag = true;
        wireframeSphereFlag = false;
        break;
    case 2:
        lightingFlag = false;
        spotLight = false;
        pointSource = true;
        break;
    }
    glutPostRedisplay(); // Displays changes
}

// Shading options
void shading(int id) {
    switch (id) {
    case 1:
        if (lightingFlag) {
            flatShadingFlag = true;
            smoothShadingFlag = false;
            calculateSphereNormals();
        }
        break;
    case 2:
        if (lightingFlag) {
            smoothShadingFlag = true;
            flatShadingFlag = false;
            calculateSphereNormals();
        }
        break;
    }
    glutPostRedisplay(); // Displays changes
}

// Lighting options
void lightingType(int id) {
    switch (id) {
    case 1:
        spotLight = true;
        pointSource = false;
        break;
    case 2:
        spotLight = false;
        pointSource = true;
        break;
    }

    glutPostRedisplay(); // Displays changes
}

// Fog options
void fog(int id) {
    switch (id) {
    case 1:
        fogType = 0;
        break;
    case 2:
        fogType = 1;
        break;
    case 3:
        fogType = 2;
        break;
    case 4:
        fogType = 3;
        break;
    }

    glutPostRedisplay();
}

// Texture mapped sphere options
void TexMS(int id) {
    switch (id) {
    case 1:
       TMS = 0;
       break;
    case 2:
       TMS = 1;
       break;
    case 3:
       TMS = 2;
       break;
    }

    glutPostRedisplay();
}

// Fireworks options
void fireworks(int id) {
    switch (id) {
        case 1:
            fireworkFlag = false;
            break;
        case 2:
            if (!fireworkFlag) {
                fireworkFlag = true;
                animationStartTime = glutGet(GLUT_ELAPSED_TIME);
            }
            break;
    }

    glutPostRedisplay();
}

// Helper Functions
void drawAxis() {
    drawObjColor(x_buffer, 3); // Draws x-axis
    drawObjColor(y_buffer, 3); // Draws y-axis
    drawObjColor(z_buffer, 3); // Draws z-axis
}

// Draws the correct floor
void drawFloor() {
    if (TMGFlag)
        drawObjTexture(floor_text, 6);
    else {
        if (lightingFlag)
            drawObjNormal(floorNormal, floor_NumVertices);
        else
            drawObjNormal(floor_buffer, floor_NumVertices);
    }
}

// Draws the correct sphere
void drawSphere(mat4 p, mat4 mv) {
    if (TMS == 0) {
        if (wireframeSphereFlag) // If true then will do wireframe otherwise will fill
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
        else // If false will fill
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

        if (lightingFlag)
            drawObjNormal(sphereNormal, sphereNumVertices);
        else
            drawObjNormal(sphere_buffer, sphereNumVertices);
    }
    else {
        wireframeSphereFlag == true;
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
        drawObjNormal(sphereNormal, sphereNumVertices);
    }
}

// Draws the correct shadow
void drawShadow() {
    if (wireframeSphereFlag && TMS == 0) // If true then will do wireframe otherwise will fill
        glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
    else // If false will fill
        glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    drawObjColor(shadow_buffer, sphereNumVertices);
}

// Sets up the lighting values for the floor
void SetUpFloorLighting(mat4 mv)
{
    glUniform4fv(glGetUniformLocation(programNormal, "AmbientProduct"),
        1, floorAP);
    glUniform4fv(glGetUniformLocation(programNormal, "DiffuseProduct"),
        1, floorDP);
    glUniform4fv(glGetUniformLocation(programNormal, "SpecularProduct"),
        1, floorSP);

    glUniform4fv(glGetUniformLocation(programNormal, "GlobalAmbientProduct"), 1, floorGA);

    // Light direction Vector
    glUniform4fv(glGetUniformLocation(programNormal, "LightPosition"),
        1, directionVec);

    vec4 pointSourceLightPos = mv * lightSource;
    glUniform4fv(glGetUniformLocation(programNormal, "PointSourceLightPosition"),
        1, pointSourceLightPos);

    glUniform1f(glGetUniformLocation(programNormal, "ConstAtt"),
        const_att);
    glUniform1f(glGetUniformLocation(programNormal, "LinearAtt"),
        linear_att);
    glUniform1f(glGetUniformLocation(programNormal, "QuadAtt"),
        quad_att);

    glUniform1f(glGetUniformLocation(programNormal, "Shininess"),
        shininessCoefficient);

    vec4 POI = mv * SLPos;
    glUniform4fv(glGetUniformLocation(programNormal, "SpotLightPOI"), 1, POI);

    glUniform4fv(glGetUniformLocation(programNormal, "eyeVec"), 1, eye);

    glUniform1f(glGetUniformLocation(programNormal, "exponent"),
        SLExp);

    glUniform1f(glGetUniformLocation(programNormal, "degree"),
        cutoff);
    
    glUniform1f(glGetUniformLocation(programNormal, "floor"), TMGFlag);
}

// Sets up the lighting values for the sphere
void SetUpSphereLighting(mat4 mv)
{
    glUniform4fv(glGetUniformLocation(programNormal, "AmbientProduct"),
        1, sphereAP);
    glUniform4fv(glGetUniformLocation(programNormal, "DiffuseProduct"),
        1, sphereDP);
    glUniform4fv(glGetUniformLocation(programNormal, "SpecularProduct"),
        1, sphereSP);

    glUniform4fv(glGetUniformLocation(programNormal, "GlobalAmbientProduct"), 1, sphereGA);

    // Directional light vector
    glUniform4fv(glGetUniformLocation(programNormal, "LightPosition"),
        1, directionVec);

    vec4 pointSourceLightPos = mv * lightSource;
    glUniform4fv(glGetUniformLocation(programNormal, "PointSourceLightPosition"),
        1, pointSourceLightPos);

    glUniform1f(glGetUniformLocation(programNormal, "ConstAtt"),
        const_att);
    glUniform1f(glGetUniformLocation(programNormal, "LinearAtt"),
        linear_att);
    glUniform1f(glGetUniformLocation(programNormal, "QuadAtt"),
        quad_att);

    glUniform1f(glGetUniformLocation(programNormal, "Shininess"),
        shininessCoefficient);

    glUniform1f(glGetUniformLocation(programNormal, "PointSource"),
        pointSource);

    glUniform1f(glGetUniformLocation(programNormal, "SpotLight"),
        spotLight);

    glUniform1f(glGetUniformLocation(programNormal, "FlatShading"),
        flatShadingFlag);

    glUniform1f(glGetUniformLocation(programNormal, "SmoothShading"),
        smoothShadingFlag);

    vec4 POI = mv * SLPos;
    glUniform4fv(glGetUniformLocation(programNormal, "SpotLightPOI"), 1, POI);

    glUniform4fv(glGetUniformLocation(programNormal, "eyeVec"), 1, eye);

    glUniform1f(glGetUniformLocation(programNormal, "exponent"),
        SLExp);

    glUniform1f(glGetUniformLocation(programNormal, "degree"),
        cutoff);

    glUniform1f(glGetUniformLocation(programNormal, "floor"), false);
}

// Calculates the correct normals for the sphere depending on flat or smooth shading
void calculateSphereNormals() {
    // Stores each vertex's color and x y and z location
    // Each vertex has the same gold color
    vec4 u, v;
    vec3 normal;
    vec4 n1, n2, n3;
    vec4 origin = { 0, 0, 0, 1 };

    for (int i = 0; i < sphereNumVertices; i += 3) {
        if (smoothShadingFlag && lightingFlag) { // Smooth shading
            n1 = sphere_points[i] - origin;
            n2 = sphere_points[i + 1] - origin;
            n3 = sphere_points[i + 2] - origin;

            sphereNormals[i].x = n1.x, sphereNormals[i].y = n1.y, sphereNormals[i].z = n1.z;
            sphereNormals[i + 1].x = n2.x, sphereNormals[i + 1].y = n2.y, sphereNormals[i + 1].z = n2.z;
            sphereNormals[i + 2].x = n3.x, sphereNormals[i + 2].y = n3.y, sphereNormals[i + 2].z = n3.z;
        } else { // Flat shading
            u = sphere_points[i + 1] - sphere_points[i];
            v = sphere_points[i + 2] - sphere_points[i];
            normal = normalize(cross(u, v));

            sphereNormals[i] = normal;
            sphereNormals[i + 1] = normal;
            sphereNormals[i + 2] = normal;
        }
    }
    glBufferSubData(GL_ARRAY_BUFFER, sizeof(point4) * sphereNumVertices, sizeof(color3) * sphereNumVertices, sphereNormals);
}

// Sets up the color program for use
void SetUpColorProgram(mat4 p, mat4 mv) {
    glUseProgram(programColor); // Use the shader program for color

    model_view = glGetUniformLocation(programColor, "model_view");
    projection = glGetUniformLocation(programColor, "projection");

    fogVar = glGetUniformLocation(programColor, "fogType");
    glUniform1i(fogVar, fogType);
    //---  Set up and pass on Projection matrix to the shader ---
    glUniformMatrix4fv(projection, 1, GL_TRUE, p); // GL_TRUE: matrix is row-major
    glUniformMatrix4fv(model_view, 1, GL_TRUE, mv); // GL_TRUE: matrix is row-major
    isColorandSphereT = glGetUniformLocation(programColor, "sphere");
    glUniform1i(isColorandSphereT, isSphere);
    isSphereT = glGetUniformLocation(programColor, "isSphere");
    glUniform1i(isSphereT, isSphere);
    isColorT = glGetUniformLocation(programColor, "isColor");
    glUniform1i(isColorT, 1);
    TMST = glGetUniformLocation(programColor, "TMS");
    glUniform1i(TMST, TMS);
    TMSDirectT = glGetUniformLocation(programColor, "TMSDirect");
    glUniform1i(TMSDirectT, TMSDirect);
    textureViewT = glGetUniformLocation(programColor, "textureView");
    glUniform1i(textureViewT, textureView);
    glUniform1i(glGetUniformLocation(programColor, "texture_1D"), 1);
    glUniform1i(glGetUniformLocation(programColor, "texture_2D"), 1);
    latticeFlagT = glGetUniformLocation(programColor, "latticeFlag");
    glUniform1i(latticeFlagT, latticeFlag);
    UTSwapT = glGetUniformLocation(programColor, "UTSwap");
    glUniform1i(UTSwapT, UTSwap);
}

// Sets up the normal program for use
void SetUpNormalProgram(mat4 p, mat4 mv, mat3 normal) {
    glUseProgram(programNormal);
    model_view = glGetUniformLocation(programNormal, "ModelView");
    projection = glGetUniformLocation(programNormal, "Projection");

    fogVar = glGetUniformLocation(programNormal, "fogType");

    glUniformMatrix4fv(projection, 1, GL_TRUE, p); // GL_TRUE: matrix is row-major
    glUniformMatrix4fv(model_view, 1, GL_TRUE, mv);
    glUniform1i(fogVar, fogType);

    isColorT = glGetUniformLocation(programNormal, "isColor");
    glUniform1i(isColorT, 0);
    glUniformMatrix3fv(glGetUniformLocation(programNormal, "Normal_Matrix"),
        1, GL_TRUE, normal);
    glUniform1i(glGetUniformLocation(programNormal, "texture_1D"), 1);

    isSphereT = glGetUniformLocation(programNormal, "isSphere");
    glUniform1i(isSphereT, isSphere);
    TMST = glGetUniformLocation(programNormal, "TMS");
    glUniform1i(TMST, TMS);
    latticeFlagT = glGetUniformLocation(programNormal, "latticeFlag");
    glUniform1i(latticeFlagT, latticeFlag);
    textureViewT = glGetUniformLocation(programNormal, "textureView");
    glUniform1i(textureViewT, textureView);
    TMSDirectT = glGetUniformLocation(programNormal, "TMSDirect");
    glUniform1i(TMSDirectT, TMSDirect);
    glUniform1i(glGetUniformLocation(programNormal, "texture_2D"), 1);
    UTSwapT = glGetUniformLocation(programNormal, "UTSwap");
    glUniform1i(UTSwapT, UTSwap);
}

// Sets up the texture program for use
void SetUpTextureProgram(mat4 p, mat4 mv) {
    glUseProgram(programTexture);
    model_view = glGetUniformLocation(programTexture, "ModelView");
    projection = glGetUniformLocation(programTexture, "Projection");
    fogVar = glGetUniformLocation(programTexture, "fogType");
    glUniform1i(fogVar, fogType);

    glUniformMatrix4fv(projection, 1, GL_TRUE, p);
    glUniform1i(glGetUniformLocation(programTexture, "texture_2D"), 1);

    glUniform4fv(glGetUniformLocation(programTexture, "uColor"), 1, floor_colors[0]);
    glUniformMatrix4fv(model_view, 1, GL_TRUE, mv);
}

// Draws the shadow and floor without blending
void drawFSNoBlend(mat4 p, mat4 mv, mat3 normal) {
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); // Fills the value

    glDepthMask(GL_FALSE); // 1
    if (TMGFlag)
        SetUpTextureProgram(p, mv);
    else if (lightingFlag) {
        SetUpNormalProgram(p, mv, normal);
        SetUpFloorLighting(mv);
    }
    drawFloor();  // draw the floor

    SetUpColorProgram(p, mv);

    glDepthMask(GL_TRUE); // 2
    if (shadowFlag) {
        drawShadow();
        calculateShadowPoints();
    }

    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // 3
    if (TMGFlag)
        SetUpTextureProgram(p, mv);
    else if (lightingFlag)
        SetUpNormalProgram(p, mv, normal);
    drawFloor();  // draw the floor

    isSphere = 1;

    SetUpNormalProgram(p, mv, normal);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // 4
}

// Draws the shadow and floor with blending
void drawFSBlend(mat4 p, mat4 mv, mat3 normal) {
    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); // Fills the value

    glDepthMask(GL_FALSE); // 1
    if (TMGFlag)
        SetUpTextureProgram(p, mv);
    else if (lightingFlag) {
        SetUpNormalProgram(p, mv, normal);
        SetUpFloorLighting(mv);
    }
    drawFloor();  // draw the floor

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    SetUpColorProgram(p, mv);

    if (shadowFlag) {
        drawShadow();
        calculateShadowPoints();
    }

    glDisable(GL_BLEND);
    glDepthMask(GL_TRUE);
    glColorMask(GL_FALSE, GL_FALSE, GL_FALSE, GL_FALSE); // 3
    if (TMGFlag)
        SetUpTextureProgram(p, mv);
    else if (lightingFlag)
        SetUpNormalProgram(p, mv, normal);
    drawFloor();  // draw the floor
    
    isSphere = 1;
    SetUpNormalProgram(p, mv, normal);
    glColorMask(GL_TRUE, GL_TRUE, GL_TRUE, GL_TRUE); // 4
}

// Sets up our 1D strip image and our 2D texture image
void image_set_up(void) {
    int i, j, c;

    for (i = 0; i < ImageHeight; i++)
        for (j = 0; j < ImageWidth; j++)
        {
            c = (((i & 0x8) == 0) ^ ((j & 0x8) == 0));

            if (c == 1)
            {
                c = 175;
                Image[i][j][0] = (GLubyte)c;
                Image[i][j][1] = (GLubyte)c;
                Image[i][j][2] = (GLubyte)c;
            }
            else
            {
                c = 105;
                Image[i][j][0] = (GLubyte)c;
                Image[i][j][1] = (GLubyte)c;
                Image[i][j][2] = (GLubyte)c;
            }

            Image[i][j][3] = (GLubyte)255;
        }

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    for (j = 0; j < stripeImageWidth; j++) {
        /* When j <= 4, the color is (255, 0, 0),   i.e., red stripe/line.
           When j > 4,  the color is (255, 255, 0), i.e., yellow remaining texture
         */
        stripeImage[4 * j] = (GLubyte)255;
        stripeImage[4 * j + 1] = (GLubyte)((j > 4) ? 255 : 0);
        stripeImage[4 * j + 2] = (GLubyte)0;
        stripeImage[4 * j + 3] = (GLubyte)255;
    }

    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
}

// Generates our initial particle values
void generateParticleValues(void) {
    float x, y, z, r, g, b;

    for (int i = 0; i < 300; i++) {
        x = 2.0 * ((rand() % 256) / 256.0 - 0.5);
        z = 2.0 * ((rand() % 256) / 256.0 - 0.5);
        y = 1.2 * 2.0 * ((rand() % 256) / 256.0 - 0.5);

        r = ((rand() % 256) / 256.0);
        g = ((rand() % 256) / 256.0);
        b = ((rand() % 256) / 256.0);

        particleVelocities[i].x = x; particleVelocities[i].y = y; particleVelocities[i].z = z;
        particleColors[i].x = r; particleColors[i].y = g; particleColors[i].z = b;
    }
}